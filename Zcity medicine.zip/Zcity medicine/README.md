Rus
Файл по пути Ваш диск:\SteamLibrary\steamapps\common\GarrysMod\garrysmod\addons\Z-City-main\lua\weapons
ENG
File in you Disk:\SteamLibrary\steamapps\common\GarrysMod\garrysmod\addons\Z-City-main\lua\weapons